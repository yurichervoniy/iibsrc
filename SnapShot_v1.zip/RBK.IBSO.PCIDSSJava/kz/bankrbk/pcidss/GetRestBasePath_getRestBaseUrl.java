package kz.bankrbk.pcidss;

import java.util.Properties;


import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import org.apache.xerces.impl.dv.util.Base64;


public class GetRestBasePath_getRestBaseUrl extends MbJavaComputeNode {
	
	private static final String SERVICE = "WAYRESTAPI";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbMessage outLocalEnv = new MbMessage(inAssembly.getLocalEnvironment());
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage(inMessage);

		try {
			
			Properties p = BrokerFacade.getUserDefinedConfigurableServiceProperties(SERVICE); 
			String url = BrokerUtils.getProperty(p, "basepath");
			int timeOut = Integer.parseInt(BrokerUtils.getProperty(p, "timeout"));
			MbElement dest = outLocalEnv.getRootElement().getFirstElementByPath("Destination");
			if(dest == null)
				dest = outLocalEnv.getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
			
			MbElement http = dest.getFirstElementByPath("HTTP");
			if(http == null)
				http = dest.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);
			
			//String OverRideUrl = null;
			MbElement reqUrl = http.getFirstElementByPath("RequestURL");
			if(reqUrl != null){
				//OverRideUrl = reqUrl.getValueAsString();
				reqUrl.delete();
			}
				
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RequestURL", url); //+ OverRideUrl); 
			
			MbElement timeOutValue = http.getFirstElementByPath("Timeout");
			if(timeOutValue == null)
				http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Timeout ", timeOut);
			
			String userName = p.getProperty("userName"); 
			if (userName == null)
				throw new MbUserException(this, "WAYRESTAPI", "", "","userName is null",  null);
			String userPassword = p.getProperty("userPassword"); 
			if (userPassword == null)
				throw new MbUserException(this, "WAYRESTAPI", "", "","userPassword is null",  null); 
			if (userName.isEmpty())
				throw new MbUserException(this, "WAYRESTAPI", "", "","userName string is empty",  null);
			
			MbElement root = outMessage.getRootElement();
			MbElement body = root.getLastChild();
			MbElement httpHeader = body.createElementBefore("HTTPRequestHeader");
			httpHeader.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Authorization", "Basic "+Base64.encode((userName+":"+userPassword).getBytes("UTF-8")));
			
		} catch (MbException e) {
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		MbMessageAssembly outAssembly = new MbMessageAssembly(
				inAssembly,
				outLocalEnv,
				inAssembly.getExceptionList(),
				outMessage);
		
		out.propagate(outAssembly); 

	}

}
