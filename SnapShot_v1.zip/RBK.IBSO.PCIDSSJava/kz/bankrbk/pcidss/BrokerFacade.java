package kz.bankrbk.pcidss;

import java.util.Properties;
import com.ibm.broker.config.proxy.BrokerProxy;
import com.ibm.broker.config.proxy.ConfigManagerProxyLoggedException;
import com.ibm.broker.config.proxy.ConfigManagerProxyPropertyNotInitializedException;
import com.ibm.broker.config.proxy.ConfigurableService;

public final class BrokerFacade {
	
	private static final String USERDEFINED = "UserDefined"; 
	private static final String CMP_LOGGED_EXCEPTION = "BrokerFacede failed to connect to broker proxy"; 
	private static final String CMP_PROP_NOT_INITIALIZED_EXCEPTION = "BrokerFacade failed to access configurable service";
	private static final String CMP_SERVICE_NULL = "BrokerFacede returned null service: ";
	private static final String PROPERTIES_NOT_DEFINED = "BrokerFacade failed to get configurable properties: "; 
	private static final String INTERRUPTED = "BrokerFacade got interrupted"; 
	private static final short BROKER_SLEEP = 100;
	private static final long BROKER_WAIT = 1000;
	private static final short BROKER_ATTEMPTS = 15;
	
	private BrokerFacade() {}
	
	private BrokerProxy b; 
	private static final BrokerFacade INSTANCE = new BrokerFacade();
	
	public static void initProxy() throws ConfigManagerProxyLoggedException, InterruptedException { 
	 { 
	    synchronized (INSTANCE) { 
	       if (INSTANCE.b == null) { 
	    	  BrokerProxy.setRetryCharacteristics(BROKER_WAIT);
	          INSTANCE.b = BrokerProxy.getLocalInstance();
	          short i = 0;
	          while (!INSTANCE.b.hasBeenPopulatedByBroker()) { 
	        	  if (i > BROKER_ATTEMPTS)
	  				throw new ConfigManagerProxyLoggedException("BrokerFacade initProxy()", "Has not been populated in "+BROKER_ATTEMPTS+" attempts each of "+BROKER_SLEEP+" ms");
	             Thread.sleep(BROKER_SLEEP); 
	             i++;
	          } 
	       } 
	    } 
	 } 
	}
	
	public final static Properties getUserDefinedConfigurableServiceProperties(final String configurableService) { 
	      try { 
	         if (INSTANCE.b == null) { 
	            initProxy(); 
	         } 
	         
	         ConfigurableService service = INSTANCE.b.getConfigurableService(USERDEFINED, configurableService); 
	         if (service == null) { 
		            throw new RuntimeException(CMP_SERVICE_NULL + configurableService); 
		         } 
	         Properties props = service.getProperties();  
	         if (props == null) { 
	            throw new RuntimeException(PROPERTIES_NOT_DEFINED); 
	         } 
	         return props; 
	      } catch (ConfigManagerProxyLoggedException ex) { 
	         throw new RuntimeException(CMP_LOGGED_EXCEPTION, ex); 
	      } catch (ConfigManagerProxyPropertyNotInitializedException ex) { 
	         throw new RuntimeException(CMP_PROP_NOT_INITIALIZED_EXCEPTION, ex); 
	      } catch (InterruptedException ex) { 
	         throw new RuntimeException(INTERRUPTED, ex); 
	      } 
	   }

}
