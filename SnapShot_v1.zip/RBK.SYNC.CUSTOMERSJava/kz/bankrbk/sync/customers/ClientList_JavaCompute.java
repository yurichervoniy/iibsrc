package kz.bankrbk.sync.customers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class ClientList_JavaCompute extends MbJavaComputeNode {
	
	private static final String NON_POOLED_SERVICE_NAME = "IBSONONPOOL";
	private static final String C_STATEMENT = "select xmlelement(\"root\",   xmlelement(\"response\",     xmlattributes('123' as \"id\", 'tst' as \"type\", 'hh' as \"operation\", 'crm' as \"system\", '0' as \"code\")     ,xmlelement(\"customers\",         XMLAGG(           xmlelement(\"customer\"             ,xmlattributes(c.id as \"id\")           )         )       )   ) ) from IBS.Z#CLIENT c";
	//private static final String C_SEL = "select c.id from IBS.Z#CLIENT c";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new empty message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		try {
			copyMessageHeaders(inMessage, outMessage);
			MbElement omroot = outMessage.getRootElement();	
			Connection con = this.getJDBCType4Connection(NON_POOLED_SERVICE_NAME, JDBC_TransactionType.MB_TRANSACTION_AUTO);
			if (con == null)
				throw new MbUserException(this, "getBrokerConnection("+NON_POOLED_SERVICE_NAME+")", "", "", "BrokerConnection is null", null);
			
			String result = executeXmlAgg(con,C_STATEMENT,60);	
			omroot.createElementAsLastChildFromBitstream(result.getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
			
			/*MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
			MbElement root= outParser.createElementAsFirstChild(MbXMLNSC.FIELD,"root",null);
			
			MbElement response = root.createElementAsLastChild(MbXMLNSC.FIELD,"response",null);	
			response.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"id","123");
			response.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"type","tst");
			response.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"operation","hello world");
			response.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"system","crm");
			response.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"code","0");
			
			MbElement customers = response.createElementAsLastChild(MbXMLNSC.FIELD,"customers",null);
			
			executeReader(con,C_SEL,60,customers);*/
			
			
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}
	
	
	public static String executeXmlAgg(final Connection conn, final String procedureName, final int timeOut) throws MbException, SQLException{
		String resp = null;
		if (conn == null) 
			throw new MbUserException("OracleInteropClob", "executeInteropProcedureClob("+procedureName+")", "", "", "Connection Parameter is null", null);
		try(PreparedStatement st = conn.prepareStatement(procedureName)) {	
			if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
				throw new MbUserException("OracleInteropClob", "executeXmlAgg("+procedureName+")", "", "", "PreparedStatement is null after call connection.prepareStatement", null);
			st.setEscapeProcessing(false);
			st.setPoolable(true);
			st.setQueryTimeout(timeOut);	
			
			try(ResultSet rs = st.executeQuery()){
				while (rs.next()) {
			        SQLXML response = rs.getSQLXML(1);
			        resp = response.getString();
			        response.free();
			      }
				rs.close();
			}
			st.close();	
			if (resp == null) 
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Response getString() is null", null);			
		}
		catch (SQLException e) {
			throw e;	
		}

		return resp;
	}
	
	public static void executeReader(final Connection conn, final String procedureName, final int timeOut, final MbElement customers) throws MbException, SQLException{
		if (conn == null) 
			throw new MbUserException("OracleInteropClob", "executeInteropProcedureClob("+procedureName+")", "", "", "Connection Parameter is null", null);
		try(PreparedStatement st = conn.prepareStatement(procedureName)) {	
			if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
				throw new MbUserException("OracleInteropClob", "executeReader("+procedureName+")", "", "", "PreparedStatement is null after call connection.prepareStatement", null);
			st.setEscapeProcessing(false);
			st.setPoolable(true);
			st.setQueryTimeout(timeOut);	
			
			try(ResultSet rs = st.executeQuery()){
				while (rs.next()) {
			        customers.createElementAsLastChild(MbXMLNSC.FIELD,"customer",rs.getString(1));
			      }
				rs.close();
			}
			st.close();	
	
		}
		catch (SQLException e) {
			throw e;	
		}

	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
