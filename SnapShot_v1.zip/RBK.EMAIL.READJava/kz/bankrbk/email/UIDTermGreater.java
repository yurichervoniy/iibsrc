package kz.bankrbk.email;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.search.SearchTerm;

import com.sun.mail.imap.IMAPFolder;

public class UIDTermGreater extends SearchTerm {
	
	private static final long serialVersionUID = 6012968967454934044L;
	private long uid;
	
	public UIDTermGreater(long uid) {
		super();
		this.uid = uid;
	}

	@Override
	public boolean match(Message msg) {
		// TODO Auto-generated method stub
		Folder folder = msg.getFolder();
		if (folder instanceof IMAPFolder) {
			IMAPFolder iFolder = (IMAPFolder) folder;
			try {
				long msgUID = iFolder.getUID(msg);
				return msgUID > uid;
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new RuntimeException(e.toString());
			}
		}
		return false;
	}

}
