package kz.bankrbk.email;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.MessagingException;

import kz.bankrbkutil.Util;

import com.github.junrar.exception.RarException;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import org.apache.commons.io.FilenameUtils;

public class Read_Mail_Box_JavaCompute extends MbJavaComputeNode {

	//private Properties properties;
	//private static final Object LOCK_OBJ = new Object();

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();
		MbElement mess = inMessage.getRootElement().getLastChild();
		MbElement mailbox = mess
				.getFirstElementByPath("root/request/ation/mailbox");
		String mail = mailbox.getValueAsString();
		MbMessageAssembly outAssembly = null;
		try {
			//properties = getProperties();
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			
			EmailCleint emailClient = new EmailCleint();
			//EmailCleint.attachment = new ArrayList<String>();

			if (mail.contains("Currrency")) {
				ProcessCurrency(emailClient,mail);
			} else if (mail.contains("Vin")) {
				ProcessVinCodes(emailClient,mail);
			} else if (mail.contains("Inn")) {
				ProcessRnn(emailClient,mail);
			}
			if (emailClient.attachment.isEmpty()) {
				MbElement root = outMessage.getRootElement();
				MbElement document = root.getLastChild().getFirstChild();
				MbElement result = document.createElementAsLastChild(
						MbElement.TYPE_NAME, "result", "No message");

				// add title attribute
				result.createElementAsFirstChild(MbXMLNSC.ATTRIBUTE, "status","ok");
			} else {
				MbElement root = outMessage.getRootElement();
				MbElement document = root.getLastChild().getFirstChild();
				MbElement result = document.createElementAsLastChild(
						MbElement.TYPE_NAME, "result", "Messages:"
								+ emailClient.attachment.size());

				result.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "status","ok");
			}
		} catch (RuntimeException e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		} catch (MessagingException e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		} catch (IOException e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		} catch (RarException e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		out.propagate(outAssembly, true);
	}

	private static void ProcessVinCodes(final EmailCleint client,String mail) throws MessagingException,
			IOException, MbUserException {
		Properties properties = getProperties();
		String host = properties.getProperty("host");
		String port = properties.getProperty("port");
		String userName = properties.getProperty("IinVinUserName");
		String password = properties.getProperty("IinVinPassword");
		long msgID = Long.parseLong(properties.getProperty("VinMsgId"));
		String from = properties.getProperty("VinFrom");
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		Date date = new Date();
		String saveDirectory = properties.getProperty("saveDirectory") + "Vin/Arhive" + dateFormat.format(date) + "/";
		String decDirectory = properties.getProperty("VinDirectory");

		File ff = new File(saveDirectory);
		if (!(ff.exists())) {
			ff.mkdir();
		}
		//EmailCleint client = new EmailCleint();
		client.setMsgID(msgID);
		client.downloadEmailAttachments(host, port, userName, password, from, saveDirectory);
		//String filename;
		for(String s : client.attachment){
			String ext = FilenameUtils.getExtension(s);
			String filename = FilenameUtils.getName(s);
			switch (ext) {
			case "txt":
				Util.copy(saveDirectory + filename, decDirectory + filename);
				break;
			default:
				File f = new File(saveDirectory + filename);
				f.delete();
				break;
			}
		}
		
		/*for (int i = 0; i < client.attachment.size(); i++) {
			String ext = FilenameUtils.getExtension(client.attachment.get(i));
			filename = FilenameUtils.getName(client.attachment.get(i));
			switch (ext) {
			case "txt":
				Util.copy(saveDirectory + filename, decDirectory + filename);
				break;
			default:
				File f = new File(saveDirectory + filename);
				f.delete();
				break;
			}
		}*/
		setMessageId(client.getMsgID(), mail);
	}

	private static void ProcessRnn(final EmailCleint client,String mail) throws MessagingException,
			IOException, RarException, MbUserException {
		Properties properties = getProperties();
		String host = properties.getProperty("host");
		String port = properties.getProperty("port");
		String userName = properties.getProperty("IinVinUserName");
		String password = properties.getProperty("IinVinPassword");
		long msgID = Long.parseLong(properties.getProperty("IinMsgId"));
		String inEnc = properties.getProperty("IinEnc");
		String outEnc = properties.getProperty("OutEnc");
		String from = properties.getProperty("IinFrom");
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		Date date = new Date();
		String saveDirectory = properties.getProperty("saveDirectory")
				+ "Rnn/Arhive" + dateFormat.format(date) + "/";
		String decDirectory = properties.getProperty("IinDirectory");
		File ff = new File(saveDirectory);
		if (!(ff.exists())) {
			ff.mkdir();
		}
		//EmailCleint client = new EmailCleint();
		client.setMsgID(msgID);
		client.downloadEmailAttachments(host, port, userName, password, from, saveDirectory);
		for(String s : client.attachment){
			String ext = FilenameUtils.getExtension(s);
			String filename = FilenameUtils.getName(s);
			switch (ext) {
			case "rar":
				Util.unrar(saveDirectory + filename, decDirectory, inEnc,
						outEnc);
				break;
			default:
				File f = new File(saveDirectory + filename);
				f.delete();
				break;
			}
		}
		
		/*for (int i = 0; i < client.attachment.size(); i++) {
			String ext = FilenameUtils.getExtension(client.attachment
					.get(i));
			filename = FilenameUtils.getName(client.attachment.get(i));
			switch (ext) {
			case "rar":
				Util.unrar(saveDirectory + filename, decDirectory, inEnc,
						outEnc);
				break;
			default:
				File f = new File(saveDirectory + filename);
				f.delete();
				break;
			}
		}*/
		setMessageId(client.getMsgID(), mail);
	}

	private static void ProcessCurrency(final EmailCleint client,String mail) throws MessagingException,
			IOException, MbUserException {
		Properties properties = getProperties();
		String host = properties.getProperty("host");
		String port = properties.getProperty("port");
		String userName = properties.getProperty("CurrUserName");
		String password = properties.getProperty("CurrPassword");
		long msgID = Long.parseLong(properties.getProperty("CurrMsgId"));
		String from = properties.getProperty("CurrFrom");
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		Date date = new Date();
		String saveDirectory = properties.getProperty("saveDirectory")
				+ "Currency/Arhive" + dateFormat.format(date) + "/";
		String decDirectory = properties.getProperty("curDirectory");
		File ff = new File(saveDirectory);
		if (!(ff.exists())) {
			ff.mkdir();
		}
		//EmailCleint client = new EmailCleint();
		client.setMsgID(msgID);
		client.downloadEmailAttachments(host, port, userName, password, from, saveDirectory);
		String filename;
		for (int i = 0; i < client.attachment.size(); i++) {
			String ext = FilenameUtils.getExtension(client.attachment.get(i));
			filename = FilenameUtils.getName(client.attachment.get(i));
			switch (ext) {
			case "xls":
				Util.copy(saveDirectory + filename, decDirectory + filename);
				break;
			case "xlsx":
				Util.copy(saveDirectory + filename, decDirectory + filename);
				break;
			default:
				File f = new File(saveDirectory + filename);
				f.delete();
				break;
			}
			setMessageId(client.getMsgID(), mail);
		}
	}

	public static synchronized void setMessageId(long l, String prop) throws MbUserException,
			IOException {
		//synchronized (LOCK_OBJ) {
			//FileInputStream in = null;
			//FileOutputStream fis = null;
			boolean isChanged = false;
			Properties property = getProperties(); //new Properties();
			if (prop.contains("Currrency")) {
				property.setProperty("CurrMsgId",Long.toString(l));
				isChanged = true;
			} else if (prop.contains("Inn")) {
				property.setProperty("IinMsgId", Long.toString(l));
				isChanged = true;
			} else if (prop.contains("Vin")) {
				property.setProperty("VinMsgId", Long.toString(l));
				isChanged = true;
			}
			else {
				throw new MbUserException(Read_Mail_Box_JavaCompute.class, "setMessageId()", "", "", "��� �������� �������� � Properties �� �������", null);
			}
			
			if(isChanged){
				try(OutputStream fis = new BufferedOutputStream(new FileOutputStream("/home/IIB/appfiles/Source/EmailClent.properties"))) {
					property.store(fis, null);
				} catch (Exception e) {
					throw new MbUserException(Read_Mail_Box_JavaCompute.class, "setMessageId()", "", "", e.toString(), null);
				} 
			}
		//}
	}

	private static synchronized Properties getProperties() throws MbUserException, IOException {
		Properties property = new Properties();
		//synchronized (LOCK_OBJ) {
			//FileInputStream fis = null;
			try(InputStream fis = new BufferedInputStream(new FileInputStream("/home/IIB/appfiles/Source/EmailClent.properties"))) {
				//fis = new FileInputStream("/home/IIB/appfiles/Source/EmailClent.properties");
				property.load(fis);
			} catch (Exception e) {
				throw new MbUserException(Read_Mail_Box_JavaCompute.class, "getProperties()", "", "", e.toString(), null);
			} /*finally {
				fis.close();
			}*/
		//}
		return property;
	}
}
