package kz.bankrbk.email;

import org.apache.commons.io.FilenameUtils;

import com.sun.mail.imap.IMAPFolder;

import javax.mail.*;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeUtility;
import javax.mail.search.AndTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.SearchTerm;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//import javax.mail.search.SearchTerm;
//import javax.mail.internet.*;

/**
 * Created by voloboy_i on 23.06.2016.
 */
public class EmailCleint {

	public EmailCleint() {
		
	}

	private long msgID;
	public List<String> attachment = new ArrayList<String>();

	public void setMsgID(long id) {
		this.msgID = id;
	}

	public long getMsgID() {
		return msgID;
	}

	public void downloadEmailAttachments(String host, String port,
			String userName, String password, String sendFrom,
			String saveDirectory) throws IOException, MessagingException {
		Properties properties = new Properties();

		// server setting
		properties.put("mail.host", host);
		properties.put("mail.port", port);
		properties.put("mail.store.protocol", "imap");
		properties.put("mail.transport.protocol", "imap");

		Session session = Session.getInstance(properties);
		// connects to the message store
		Store store = null;
		try {
			store = session.getStore("imap");
			store.connect(userName, password);
			
			IMAPFolder folderInbox = null;
			try {
				folderInbox = (IMAPFolder) store.getFolder("INBOX");
				folderInbox.open(Folder.READ_ONLY);
				
				//Message[] uidSearch = folderInbox.getMessagesByUID(this.msgID, Long.MAX_VALUE); //me
				Message[] folderMsgs = folderInbox.getMessages(); //me
				
				FromStringTerm fromTerm = new FromStringTerm(sendFrom);
				UIDTermGreater uidGreater = new UIDTermGreater(this.msgID);
				SearchTerm andTerm = new AndTerm(uidGreater, fromTerm); // ???
				
				//Message[] arrayMessages = folderInbox.search(fromTerm);
				//Message[] arrayMessages = search(fromTerm, folderMsgs); //me
				Message[] arrayMessages = search(andTerm, folderMsgs); //me
				
				for (int i = 0; i < arrayMessages.length; i++) {					
					Message message = arrayMessages[i];
					long currentUID = folderInbox.getUID(message);
					File f = new File(saveDirectory);
					if (!f.exists()) {
						throw new IOException(
								"�� ������� ��������� ���� �� ���������� ����:'"
										+ saveDirectory + "' ���������� �� �������");
					}
					// Double Check for UID
					if ( msgID < currentUID) {
						String contentType = message.getContentType();
						// store attachment file name, separated by comma
						String attachFiles = "";
						if (contentType.contains("multipart")) {
							// content may contain attachments
							Multipart multiPart = (Multipart) message.getContent();
							int numberOfParts = multiPart.getCount();
							for (int partCount = 0; partCount < numberOfParts; partCount++) {
								MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(partCount);	
								String disposition = part.getDisposition();
								if (part != null && Part.ATTACHMENT.equalsIgnoreCase(disposition)) {
									// this part is attachment
									String partFileName = part.getFileName();
									if (partFileName == null)
										continue;
									String fileName = MimeUtility.decodeText(part.getFileName());
									attachFiles += fileName + ", ";
									File in = new File(saveDirectory + File.separator + fileName);
									String name = in.getName();
									for (String targetPath = in.getParentFile().getPath(); in.exists(); in = new File(targetPath + "/" + name)) {
										String ext = FilenameUtils.getExtension(in.getPath());
										name = name.replace("." + ext, "") + "_n."+ ext;
									}

									part.saveFile(saveDirectory + File.separator + name);
									if (name.endsWith(".rar")) {
										if (checkWithRegExp(name)) {
											attachment.add(name);
										} else if (!(name.contains(".part"))) {
											attachment.add(name);
										}
									} else {
										attachment.add(name);
									}
								}
							}

							if (attachFiles.length() > 1) {
								attachFiles = attachFiles.substring(0,
										attachFiles.length() - 2);
							}
						} else if (contentType.contains("text/plain")
								|| contentType.contains("text/html")) {
							Object content = message.getContent();
							if (content != null) {
							}
						}
					}
					if ( msgID < currentUID ) {
						setMsgID(currentUID);
					}
				}
			}
			finally {
				if(folderInbox!=null){
					try{
						folderInbox.close(false);
					}
					finally {
						folderInbox = null;
					}
				}
			}
		}
		finally {
			if(store!=null){
				try{
					store.close();
				}
				finally {
					store = null;
				}
			}
		}
		
	}

	public static boolean checkWithRegExp(String userNameString) {
		Pattern p = Pattern.compile(".+(part(0?)*1).rar");
		Matcher m = p.matcher(userNameString);
		return m.matches();
	}
	
	private static Message[] search(SearchTerm term, Message[] msgs) throws MessagingException {  
        Message[] inMsgs = msgs;
        int len = msgs.length;
        List<Message> matchedMsgs = new ArrayList<Message>(len);

        for(int i = 0; i < len; ++i) {
            Message msg = inMsgs[i];
            try {
                if(msg.match(term)) {
                    matchedMsgs.add(msg);
                }
            } catch (MessageRemovedException var9) {
                ;
            }
        }

        return (Message[])matchedMsgs.toArray(new Message[matchedMsgs.size()]);
    }
}