package kz.bankrbk.aq;

import com.ibm.broker.config.appdev.InputTerminal;
import com.ibm.broker.config.appdev.Node;
import com.ibm.broker.config.appdev.NodeProperty;
import com.ibm.broker.config.appdev.OutputTerminal;

/*** 
 * <p>  <I>AqInputNodeUDN</I> instance</p>
 * <p></p>
 */
public class AqInputNodeUDN extends Node {

	private static final long serialVersionUID = 1L;

	// Node constants
	protected final static String NODE_TYPE_NAME = "kz/bankrbk/aq/AqInputNode";
	protected final static String NODE_GRAPHIC_16 = "platform:/plugin/kz.bankrbk.aq/icons/full/obj16/kz/bankrbk/aq/AqInput.gif";
	protected final static String NODE_GRAPHIC_32 = "platform:/plugin/kz.bankrbk.aq/icons/full/obj30/kz/bankrbk/aq/AqInput.gif";

	protected final static String PROPERTY_QUEUENAME = "queueName";
	protected final static String PROPERTY_JDBCTYPE4CONNECTION = "jdbcType4Connection";
	protected final static String PROPERTY_WAITINTERVAL = "waitInterval";
	protected final static String PROPERTY_PAYLOADTYPE = "payLoadType";
	protected final static String PROPERTY_CONSUMERNAME = "consumerName";

	protected NodeProperty[] getNodeProperties() {
		return new NodeProperty[] {
			new NodeProperty(AqInputNodeUDN.PROPERTY_QUEUENAME,		NodeProperty.Usage.MANDATORY,	false,	NodeProperty.Type.STRING, null,"","",	"kz/bankrbk/aq/AqInput",	"kz.bankrbk.aq"),
			new NodeProperty(AqInputNodeUDN.PROPERTY_JDBCTYPE4CONNECTION,		NodeProperty.Usage.MANDATORY,	false,	NodeProperty.Type.STRING, null,"","",	"kz/bankrbk/aq/AqInput",	"kz.bankrbk.aq"),
			new NodeProperty(AqInputNodeUDN.PROPERTY_WAITINTERVAL,		NodeProperty.Usage.MANDATORY,	false,	NodeProperty.Type.INTEGER, "5","","",	"kz/bankrbk/aq/AqInput",	"kz.bankrbk.aq"),
			new NodeProperty(AqInputNodeUDN.PROPERTY_PAYLOADTYPE,		NodeProperty.Usage.MANDATORY,	false,	NodeProperty.Type.STRING, "XMLType","","",	"kz/bankrbk/aq/AqInput",	"kz.bankrbk.aq"),
			new NodeProperty(AqInputNodeUDN.PROPERTY_CONSUMERNAME,		NodeProperty.Usage.OPTIONAL,	false,	NodeProperty.Type.STRING, null,"","",	"kz/bankrbk/aq/AqInput",	"kz.bankrbk.aq")
		};
	}

	public AqInputNodeUDN() {
	}

	@Override
	public InputTerminal[] getInputTerminals() {
		return null;
	}

	public final OutputTerminal OUTPUT_TERMINAL_OUT = new OutputTerminal(this,"OutTerminal.out");
	public final OutputTerminal OUTPUT_TERMINAL_FAILURE = new OutputTerminal(this,"OutTerminal.failure");
	@Override
	public OutputTerminal[] getOutputTerminals() {
		return new OutputTerminal[] {
			OUTPUT_TERMINAL_OUT,
			OUTPUT_TERMINAL_FAILURE
		};
	}

	@Override
	public String getTypeName() {
		return NODE_TYPE_NAME;
	}

	protected String getGraphic16() {
		return NODE_GRAPHIC_16;
	}

	protected String getGraphic32() {
		return NODE_GRAPHIC_32;
	}

	/**
	 * Set the <I>AqInputNodeUDN</I> "<I>queueName</I>" property
	 * 
	 * @param value String ; the value to set the property "<I>queueName</I>"
	 */
	public AqInputNodeUDN setQueueName(String value) {
		setProperty(AqInputNodeUDN.PROPERTY_QUEUENAME, value);
		return this;
	}

	/**
	 * Get the <I>AqInputNodeUDN</I> "<I>queueName</I>" property
	 * 
	 * @return String; the value of the property "<I>queueName</I>"
	 */
	public String getQueueName() {
		return (String)getPropertyValue(AqInputNodeUDN.PROPERTY_QUEUENAME);
	}

	/**
	 * Set the <I>AqInputNodeUDN</I> "<I>jdbcType4Connection</I>" property
	 * 
	 * @param value String ; the value to set the property "<I>jdbcType4Connection</I>"
	 */
	public AqInputNodeUDN setJdbcType4Connection(String value) {
		setProperty(AqInputNodeUDN.PROPERTY_JDBCTYPE4CONNECTION, value);
		return this;
	}

	/**
	 * Get the <I>AqInputNodeUDN</I> "<I>jdbcType4Connection</I>" property
	 * 
	 * @return String; the value of the property "<I>jdbcType4Connection</I>"
	 */
	public String getJdbcType4Connection() {
		return (String)getPropertyValue(AqInputNodeUDN.PROPERTY_JDBCTYPE4CONNECTION);
	}

	/**
	 * Set the <I>AqInputNodeUDN</I> "<I>waitInterval</I>" property
	 * 
	 * @param value int ; the value to set the property "<I>waitInterval</I>"
	 */
	public AqInputNodeUDN setWaitInterval(int value) {
		setProperty(AqInputNodeUDN.PROPERTY_WAITINTERVAL, Integer.toString(value));
		return this;
	}

	/**
	 * Get the <I>AqInputNodeUDN</I> <I>waitInterval</I> property
	 * 
	 * @return int; the value of the property "<I>waitInterval</I>"
	 */
	public int getWaitInterval() {
		String value = (String)getPropertyValue(AqInputNodeUDN.PROPERTY_WAITINTERVAL);
		return Integer.valueOf(value).intValue();
	}

	/**
	 * Set the <I>AqInputNodeUDN</I> "<I>payLoadType</I>" property
	 * 
	 * @param value String ; the value to set the property "<I>payLoadType</I>"
	 */
	public AqInputNodeUDN setPayLoadType(String value) {
		setProperty(AqInputNodeUDN.PROPERTY_PAYLOADTYPE, value);
		return this;
	}

	/**
	 * Get the <I>AqInputNodeUDN</I> "<I>payLoadType</I>" property
	 * 
	 * @return String; the value of the property "<I>payLoadType</I>"
	 */
	public String getPayLoadType() {
		return (String)getPropertyValue(AqInputNodeUDN.PROPERTY_PAYLOADTYPE);
	}

	/**
	 * Set the <I>AqInputNodeUDN</I> "<I>consumerName</I>" property
	 * 
	 * @param value String ; the value to set the property "<I>consumerName</I>"
	 */
	public AqInputNodeUDN setConsumerName(String value) {
		setProperty(AqInputNodeUDN.PROPERTY_CONSUMERNAME, value);
		return this;
	}

	/**
	 * Get the <I>AqInputNodeUDN</I> "<I>consumerName</I>" property
	 * 
	 * @return String; the value of the property "<I>consumerName</I>"
	 */
	public String getConsumerName() {
		return (String)getPropertyValue(AqInputNodeUDN.PROPERTY_CONSUMERNAME);
	}

	public String getNodeName() {
		String retVal = super.getNodeName();
		if ((retVal==null) || retVal.equals(""))
			retVal = "AqInput";
		return retVal;
	};
}
