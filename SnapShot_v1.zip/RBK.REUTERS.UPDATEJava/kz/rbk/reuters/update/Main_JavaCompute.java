package kz.rbk.reuters.update;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.zip.GZIPInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;


import org.apache.commons.codec.binary.Base64;

public class Main_JavaCompute extends MbJavaComputeNode {

	private static final String SERVICE = "AMLSERVICE";
	private static String amlIportPath;
	//= "/home/IIB/Logs/Reuters";
    
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			amlIportPath = BrokerFacade.getUserDefinedConfigurableServiceProperties(SERVICE, "reuters_upload_path");
			
		    MbElement request = inMessage.getRootElement().getLastChild().getFirstElementByPath("root/request");
		    String operation = request.getFirstElementByPath("operation").getValueAsString();
		    boolean forseFullWorldCheckUpdate = false;
		    
		    if(operation.equals("fullupdate")){
	    		forseFullWorldCheckUpdate = true;
		    }
		    
		    UpdateWorldCheck(forseFullWorldCheckUpdate);
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}
	
	
	public static void UpdateWorldCheck(boolean full) throws IOException{
       String filename = full ? "world-check.xml.gz" : "world-check-day.xml.gz";
       String deletefilename = full ? "world-check-deleted-v2.xml.gz" : "world-check-deleted-day-v2.xml.gz";
    
           
       File tempDirectory = File.createTempFile("temp", Long.toString(System.nanoTime()));
       tempDirectory.delete();
       boolean isCreated = tempDirectory.mkdir();
    
       String xmlfile = GetUrlXDocument(tempDirectory.getAbsolutePath(), filename);
	   
       if(xmlfile != ""){
    	   File f = new File(amlIportPath);
   			if(!f.exists() || !f.isDirectory()){
    		   f.createNewFile();
   			}
    	   
    	   
    	   Date date = new Date();
           DateFormat dateFormat = new SimpleDateFormat("_yyyy-MM-dd_HHmm");
           String dstFilePath = FilenameUtils.concat(amlIportPath, FilenameUtils.removeExtension(xmlfile) +   dateFormat.format(date) + FilenameUtils.EXTENSION_SEPARATOR + FilenameUtils.getExtension(xmlfile));
           File dstFile = new File(dstFilePath);
           if (dstFile.exists()) {
               dstFile.delete();
           }
           FileUtils.copyFile( new File(FilenameUtils.concat(tempDirectory.getAbsolutePath(), xmlfile)), dstFile);
       }
       
       xmlfile = GetUrlXDocument(tempDirectory.getAbsolutePath(), deletefilename);
	   
       if(xmlfile != ""){
    	   File f = new File(amlIportPath);
   			if(!f.exists() || !f.isDirectory()){
    		   f.createNewFile();
   			}
    	   
    	   
    	   Date date = new Date();
           DateFormat dateFormat = new SimpleDateFormat("_yyyy-MM-dd_HHmm");
           String dstFilePath = FilenameUtils.concat(amlIportPath, FilenameUtils.removeExtension(xmlfile) +   dateFormat.format(date) +FilenameUtils.EXTENSION_SEPARATOR + FilenameUtils.getExtension(xmlfile));
           File dstFile = new File(dstFilePath);
           if (dstFile.exists()) {
               dstFile.delete();
           }
           FileUtils.copyFile( new File(FilenameUtils.concat(tempDirectory.getAbsolutePath(), xmlfile)), dstFile);
       }
	}

    private static String GetUrlXDocument(String tempdirectory, String filename) throws MalformedURLException, IOException {
    	String urlStr = "https://www.world-check.com/portal/Downloads/" + filename ;

	    String user = "kznkrn0002";
	    String pass = "456";
	    	
	    String xmlName = "";
		URL urlObj = new URL(urlStr);
		String authStr = user + ":" + pass;
        String authEncoded = Base64.encodeBase64String(authStr.getBytes("UTF8"));
        
        /*
        Authenticator.setDefault(new ProxyAuthenticator("utegaliyev_n", "qwerty_333"));
        System.setProperty("https.proxyHost", "10.1.6.133");
        System.setProperty("https.proxyPort", "3128");
        */
        
        HttpsURLConnection con =  (HttpsURLConnection)urlObj. openConnection();

		
        con.addRequestProperty("Authorization", "Basic " + authEncoded);	
        con.addRequestProperty("Connection", "keep-alive");	
		con.setRequestMethod("GET");
		//add request header
		con.setRequestProperty("User-Agent", "Bank RBK, Kazakchstan");
		InputStream resultStream = null;
		con.connect();
		int responseCode = con.getResponseCode();
		
		if(responseCode==HttpURLConnection.HTTP_OK){
			String  contentType = con.getContentType();
			InputStream inputStream =  con.getInputStream();
			if(contentType.contains("gzip")){
				resultStream = new GZIPInputStream(inputStream);
				xmlName = FilenameUtils.removeExtension(filename);
			}else if(contentType.contains("xml")){
				xmlName = filename;
				resultStream = con.getInputStream();
			}else{
				xmlName = filename;
				resultStream = con.getInputStream();
			}
			
			if(xmlName != ""){
				byte[] buffer = new byte[512];
				OutputStream fs = new FileOutputStream(new File( tempdirectory +  System.getProperty("file.separator")  + xmlName));
				
				int read;
				
	            while ((read = resultStream.read(buffer)) > 0) {
	                fs.write(buffer, 0, read);
	            }
	            fs.flush();
	            fs.close();
	            resultStream.close();
			}
			
		}
		
    	return xmlName;
    }
    
    
    
    

}
