package kz.bankrbk.connectors;

import java.util.Properties;

import org.apache.xerces.impl.dv.util.Base64;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class Process_Request_1C_JavaCompute extends MbJavaComputeNode {
	
	private static final String SERVICE = "WEBSERVICE1C";

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		try {
			MbMessage inMessage = assembly.getMessage();
			MbMessage outLocalEnv = new MbMessage(assembly.getLocalEnvironment());
			//OutputLocalEnvironment.Destination.SOAP.Request.Transport.HTTP.WebServiceURL
			MbElement dest = outLocalEnv.getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
			MbElement soap = dest.createElementAsLastChild(MbElement.TYPE_NAME, "SOAP", null);
			MbElement req = soap.createElementAsLastChild(MbElement.TYPE_NAME, "Request", null);
			MbElement transport = req.createElementAsLastChild(MbElement.TYPE_NAME, "Transport", null);
			MbElement http = transport.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);
			Properties p = BrokerFacade.getUserDefinedConfigurableServiceProperties(SERVICE);
			String url = BrokerUtils.getProperty(p, "url");
			int timeOut = Integer.parseInt(BrokerUtils.getProperty(p, "timeout"));
			boolean authBasic = Boolean.parseBoolean(BrokerUtils.getProperty(p, "basicAuth"));	
			
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "WebServiceURL", url); 
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Timeout ", timeOut);
			
			MbMessage outMessage = null;
			
			if (authBasic) {
				String userName = p.getProperty("userName"); 
				if (userName == null)
					throw new MbUserException(this, "Auth 1C", "", "","userName is null",  null);
				String userPassword = p.getProperty("userPassword"); 
				if (userPassword == null)
					throw new MbUserException(this, "Auth 1C", "", "","userPassword is null",  null); 
				if (userName.isEmpty())
					throw new MbUserException(this, "Auth 1C", "", "","userName string is empty",  null);
				if(userName != null) {
					outMessage = new MbMessage(inMessage);
					MbElement root = outMessage.getRootElement();
					MbElement body = root.getLastChild();
					MbElement httpHeader = body.createElementBefore("HTTPRequestHeader");
					httpHeader.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Authorization", "Basic "+Base64.encode((userName+":"+userPassword).getBytes("UTF-8")));
				}
			}
			else {
				outMessage = inMessage;
			}
			
			MbMessageAssembly outAssembly = new MbMessageAssembly(
					assembly,
					outLocalEnv,
					assembly.getExceptionList(),
					outMessage);
			
			out.propagate(outAssembly); 
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
	}

}
