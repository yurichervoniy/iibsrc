package kz.bankrbk.connectors;

import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public final class Hermes_API_UCP_JavaCompute extends MbJavaComputeNode {
	
	private static final String HERMES_PROCEDURE = "BEGIN IBS.HERMES_API(:request,:response); END;";
	private static final String HERMES_PROCEDURE_CLOB = "BEGIN IBS.HERMES_API(sys.xmltype.createXML(:request),:response); END;";
	private static final String POOLED_SERVICE_NAME = "HERMESIBSO";
	private static final String NON_POOLED_SERVICE_NAME = "IBSONONPOOL";	
	

	public void evaluate(final MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		
		boolean propogateAlt = true;
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);
		int statementTimeout = getStatementTimeOut();
		String serviceName = usePooledConnection() ? POOLED_SERVICE_NAME : NON_POOLED_SERVICE_NAME;
		
		try {	
			copyMessageHeaders(inMessage,outMessage);				
			MbElement msg = inMessage.getRootElement().getLastChild();
			if (msg==null) 
				throw new MbUserException(this, "Hermes-evaluate()", "", "", "Message MbElement is null", null);			
			String request = new String(msg.toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8");
			if(disableLogTrafic())
				propogateAlt = false;
			MbElement omroot = outMessage.getRootElement();					
			Connection con = this.getJDBCType4Connection(serviceName, JDBC_TransactionType.MB_TRANSACTION_AUTO); // Do not close connection, Broker handles them//		
			if (con == null)
				throw new MbUserException(this, "getBrokerConnection("+serviceName+")", "", "", "BrokerConnection is null", null);
			
			boolean asClob = inputAsClob(); 
			String procedure = asClob ? HERMES_PROCEDURE_CLOB : HERMES_PROCEDURE;

			if(setOracleInfo()){
				try {
					OracleInterop.setApplicationInfo(con, getExecutionServerName(), getPrettyMessageFlowName(), 3);
					//con.setClientInfo("OCSID.CLIENTID", getBrokerName());
					//con.setClientInfo("OCSID.MODULE", getExecutionServerName());
					//con.setClientInfo("OCSID.ACTION", getPrettyMessageFlowName());
				}
				catch(SQLException sqe){
					OracleInterop.setEnvorimentSQLException(inAssembly, sqe);
					throw new MbUserException(this, "Oracle setApplicationInfo Procedure Call", "", "", sqe.toString(), null);
				}
				
			}	
			
			String response = null;
			try {
				if (asClob)
					response = OracleInterop.executeInteropProcedureClob(con, request, procedure, statementTimeout);
				else
					response = OracleInterop.executeInteropProcedure(con, request, procedure, statementTimeout);
			}
			catch(SQLException se){
				OracleInterop.setEnvorimentSQLException(inAssembly, se);
				throw new MbUserException(this, "Hermes Procedure Call", "", "", se.toString(), null);
			}
			
			if (response == null)
				throw new MbUserException(this, "Hermes_Evaluate", "", "", "Hermes Procedure Call returned null", null);
			
			writeMessageBody(response, omroot);

		} 
		catch (Exception e) {
			OracleInterop.notifyException(alt,inAssembly, e, serviceName, statementTimeout);
			OracleInterop.clearMessage(outMessage);
			outMessage = null;	
			if(e instanceof MbException)
				throw (MbException)e;
			else if(e instanceof RuntimeException)
				throw (RuntimeException)e;
			else
				throw new MbUserException(this, "evaluateHermes()", "", "", e.toString(),null);		
		}
		
		if (propogateAlt){
			outMessage.finalizeMessage(MbMessage.FINALIZE_NONE);
			alt.propagate(outAssembly);
		}
		
		outMessage.finalizeMessage(MbMessage.FINALIZE_NONE);
		out.propagate(outAssembly,true);
		
	}	
	
	/*private String getBrokerName(){
		try {
			return this.getBroker().getName();
		}
		catch(Exception e){
			return "n/a";
		}
	}*/
	
	private String getExecutionServerName(){
		try {
			return this.getExecutionGroup().getName();
		}
		catch(Exception e){
			return "n/a";
		}
	}
	
	private String getPrettyMessageFlowName(){
		try {
			String[] a = this.getMessageFlow().getName().split("\\.");
			return a[a.length-1];
		}
		catch(Exception e){
			return "n/a";
		}	
	}
	
	private int getStatementTimeOut(){
		int timeOut=120;
		try {
			timeOut=Integer.parseInt(this.getUserDefinedAttribute("TimeOut").toString());
			if (timeOut<=0) 
				timeOut=120;
		}
		catch(Exception e){
			timeOut=120;
		}
		return timeOut; 
	}
	
	private boolean usePooledConnection(){
		boolean pc = false;
		try {
			pc = Boolean.parseBoolean(this.getUserDefinedAttribute("UsePooledConnection").toString());
		}
		catch(Exception e){
			pc = false;
		}
		return pc; 
	}
	
	private boolean disableLogTrafic(){
		boolean dl = false;
		try {
			dl = Boolean.parseBoolean(this.getUserDefinedAttribute("DisableLog").toString());
		}
		catch(Exception e){
			dl = false;
		}
		return dl; 
	}
	
	private boolean disableEncodeKazWin(){
		boolean ek = false;
		try {
			ek = Boolean.parseBoolean(this.getUserDefinedAttribute("DisableKazWinEncode").toString());
		}
		catch(Exception e){
			ek = false;
		}
		return ek; 
	}
	
	private boolean setOracleInfo(){
		boolean oi = false;
		try {
			oi = Boolean.parseBoolean(this.getUserDefinedAttribute("SetOracleInfo").toString());
		}
		catch(Exception e){
			oi = false;
		}
		return oi; 
	}
	
	private boolean inputAsClob(){
		boolean a = false;
		try {
			a = Boolean.parseBoolean(this.getUserDefinedAttribute("InputAsClob").toString());
		}
		catch(Exception e){
			a = false;
		}
		return a; 
	}

	
	private void writeMessageBody(final String resp, final MbElement root) throws MbException {	
		boolean convert = true;
		if(disableEncodeKazWin())
			convert = false;
		try {
			OracleInterop.writeMessageBodyAsString(resp, convert, root);
		}
		catch(Exception e){
			throw new MbUserException(this, "Hermes writeMessageBody", "", "", e.toString(), null);
		}
		
	}	

	public void copyMessageHeaders(final MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) 
		{
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}
	}

}
