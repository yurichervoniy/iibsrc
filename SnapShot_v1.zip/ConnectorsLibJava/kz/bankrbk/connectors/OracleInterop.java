package kz.bankrbk.connectors;

import java.io.UnsupportedEncodingException;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Types;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbJavaException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public final class OracleInterop {
	
	private static final String SET_APP_INFO = "BEGIN dbms_application_info.set_module(:module,:action); END;";
	
	private OracleInterop(){}
	
	public static void setApplicationInfo(final Connection conn, final String module, final String action, final int timeOut) throws MbException, SQLException{
		if (conn == null) 
			throw new MbUserException("setApplicationInfo", "setApplicationInfo()", "", "", "Connection Parameter is null", null);
		if(module==null)
			throw new MbUserException("setApplicationInfo", "setApplicationInfo()", "", "", "module Parameter is null", null);
		if(action==null)
			throw new MbUserException("setApplicationInfo", "setApplicationInfo()", "", "", "action Parameter is null", null);
		
		try(CallableStatement st = conn.prepareCall(SET_APP_INFO)) {	
			if (st == null) 
				throw new MbUserException("setApplicationInfo", "setApplicationInfo()", "", "", "CallableStatement is null after call connection.prepareCall", null);
			//st.setEscapeProcessing(false);
			//st.setPoolable(true);
			//st.setQueryTimeout(timeOut);	
			st.setString(1, module);
			st.setString(2, action);
			st.execute();
			st.close();			
		}
		catch (SQLException e) {
			throw e;	
		}

	}
	
	public static void setEnvorimentSQLException(final MbMessageAssembly inAssembly, final SQLException se){	
		try {
			MbElement root = inAssembly.getGlobalEnvironment().getRootElement();
			MbElement seElement = root.getFirstElementByPath("SQLException");
			if (seElement!=null)
				seElement.delete();
			seElement = root.createElementAsFirstChild(MbElement.TYPE_NAME, "SQLException", null);
			seElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ErrorCode", se.getErrorCode());
			seElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SQLState", se.getSQLState());
			seElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Message", se.getMessage());
		} catch (MbException e1) {
			e1.printStackTrace();
		}		
	}
	
	public static void notifyException(final MbOutputTerminal terminal,final MbMessageAssembly inAssembly, final Exception e, final String serviceName, final int timeOut){	
		MbMessage altMessage=null;
		try {
			altMessage = new MbMessage();
			MbMessageAssembly altAssembly = new MbMessageAssembly(inAssembly,altMessage);
			MbElement outParser = altMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
			MbElement root= outParser.createElementAsFirstChild(MbXMLNSC.FIELD,"root",null);
			root.createElementAsLastChild(MbXMLNSC.FIELD,"servicename",serviceName);
			root.createElementAsLastChild(MbXMLNSC.FIELD,"timeout",timeOut);	
			MbElement errors= root.createElementAsLastChild(MbXMLNSC.FIELD,"errors",null);			
			if (e instanceof MbException){
				MbException me = (MbException)e;
				traverseExceptions(errors,me,0);
			}
			else{
				MbElement error= errors.createElementAsFirstChild(MbXMLNSC.FIELD,"error",null);
				if (e instanceof SQLException) {
					error.createElementAsLastChild(MbXMLNSC.FIELD,"sqlcode",((SQLException)e).getErrorCode());
					error.createElementAsLastChild(MbXMLNSC.FIELD,"sqlstate",((SQLException)e).getSQLState());
				}
				error.createElementAsLastChild(MbXMLNSC.FIELD,"text",e.toString());
				error.createElementAsLastChild(MbXMLNSC.FIELD,"details",e.getMessage());
				
			}
			terminal.propagate(altAssembly);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally {
			clearMessage(altMessage);
			altMessage = null;
		}
	}
	
	private static void traverseExceptions(final MbElement errors,final MbException ex, int level) throws MbException{
	    if(ex != null)
	      {
	    	MbElement error= errors.createElementAsLastChild(MbXMLNSC.FIELD,"error",null);
	        error.createElementAsLastChild(MbXMLNSC.FIELD,"text",ex.getTraceText());
			error.createElementAsLastChild(MbXMLNSC.FIELD,"details","Level=" + Integer.toString(level) + ex.toString() + " - " + ex.getMessage());
			if( ex instanceof MbJavaException )
			  {
				MbElement javaError= errors.createElementAsLastChild(MbXMLNSC.FIELD,"error",null);
				javaError.createElementAsLastChild(MbXMLNSC.FIELD,"text",((MbJavaException)ex).getThrowable().toString());
	          }

	        MbException e[] = ex.getNestedExceptions();
	        int size = e.length;
	        for(int i = 0; i < size; i++)
	          {
	        	traverseExceptions(errors, e[i], level + 1);
	          }
	      }
	}
	
	public static void clearMessage(MbMessage message){
		if (message!=null){
			try {
				message.clearMessage();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	/*private static void doRollBack(Connection con){
		if (con != null){
			try {
				con.rollback();
			} catch (SQLException se) {
			} 
		}
	}*/
	
	private static void executeCallableStatement(CallableStatement stm, int retryCount) throws SQLException{
		try {
			stm.execute(); 
		}
		catch(SQLException e){
			int errorCode = e.getErrorCode(); 
			if (retryCount>0 && "72000".equals(e.getSQLState()) && (errorCode==4068 || errorCode==4061 || errorCode==4065 || errorCode==4067) ){
				executeCallableStatement(stm, --retryCount);	
			}											
			else
				throw e;
		}
	}
	
	public static String executeInteropProcedure(final Connection conn, final String req, final String procedureName, final int timeOut) throws MbException, SQLException{
		String resp = null;
		if (conn == null) 
			throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Connection Parameter is null", null);
		try(CallableStatement st = conn.prepareCall(procedureName)) {	
			if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "CallableStatement is null after call connection.prepareCall", null);
			st.setEscapeProcessing(false);
			st.setPoolable(true);
			st.setQueryTimeout(timeOut);	
			SQLXML request = conn.createSQLXML();
			request.setString(Decoders.Utf8ToKazWin(req));
			st.setSQLXML(1, request);
			st.registerOutParameter(2,Types.SQLXML);
			executeCallableStatement(st,2);
			SQLXML response = st.getSQLXML(2);
			st.close();	
			request.free();
			if (response == null) 
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Response is null", null);	
			resp = response.getString();
			response.free();
			if (resp == null) 
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Response getString() is null", null);			
		}
		catch (SQLException e) {
			//doRollBack(conn);
			throw e;	
		}

		return resp;
	}
	
	public static String executeInteropProcedureClob(final Connection conn, final String req, final String procedureName, final int timeOut) throws MbException, SQLException{
		String resp = null;
		if (conn == null) 
			throw new MbUserException("OracleInteropClob", "executeInteropProcedureClob("+procedureName+")", "", "", "Connection Parameter is null", null);
		try(CallableStatement st = conn.prepareCall(procedureName)) {	
			if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
				throw new MbUserException("OracleInteropClob", "executeInteropProcedureClob("+procedureName+")", "", "", "CallableStatement is null after call connection.prepareCall", null);
			st.setEscapeProcessing(false);
			st.setPoolable(true);
			st.setQueryTimeout(timeOut);	
			Clob request = conn.createClob();
			request.setString(1, Decoders.Utf8ToKazWin(req));
			st.setClob(1, request);
			st.registerOutParameter(2,Types.SQLXML);
			executeCallableStatement(st,2);
			SQLXML response = st.getSQLXML(2);
			st.close();	
			request.free();
			if (response == null) 
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Response is null", null);	
			resp = response.getString();
			response.free();
			if (resp == null) 
				throw new MbUserException("OracleInterop", "executeInteropProcedure("+procedureName+")", "", "", "Response getString() is null", null);			
		}
		catch (SQLException e) {
			//doRollBack(conn);
			throw e;	
		}

		return resp;
	}
	
	public static void writeMessageBodyAsString(final String resp,final boolean convert, final MbElement root) throws MbException, UnsupportedEncodingException{
		if(convert){
			root.createElementAsLastChildFromBitstream(Decoders.KazWinToUtf8(resp).getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
		}
		else{
			root.createElementAsLastChildFromBitstream(resp.getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
		}
	}
	
}
