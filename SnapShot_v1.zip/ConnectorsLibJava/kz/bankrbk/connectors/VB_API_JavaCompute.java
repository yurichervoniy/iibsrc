package kz.bankrbk.connectors;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Types;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class VB_API_JavaCompute extends MbJavaComputeNode {
	
	private static final String PROC_NAME = "{CALL IBM_IIB.process_request(?, ?)}";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);

		try {	
			copyMessageHeaders(inMessage,outMessage);		
			String messageBody = new String(inMessage.getRootElement().getLastChild().toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0),"UTF-8"); 
			MbElement omroot = outMessage.getRootElement();	
			processVb6(messageBody,omroot);		
			
		} catch (MbException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new MbUserException(this, "evaluateVb6()", "", "", e.toString(),null);
		}

		out.propagate(outAssembly);
	}

	private void processVb6(String messageBody, MbElement root) throws MbException{	
		Connection con = this.getJDBCType4Connection("VABANK", JDBC_TransactionType.MB_TRANSACTION_AUTO);
		try(CallableStatement st = con.prepareCall(PROC_NAME)) {
			st.setQueryTimeout(180);
			
			SQLXML request = con.createSQLXML();
			request.setString(Decoders.Utf8ToKazWin(messageBody));
			st.setSQLXML(1, request);
			st.registerOutParameter(2,Types.SQLXML);
			st.execute();
			SQLXML response = st.getSQLXML(2);
			st.close();
			
			writeMessageBodyAsString(response,root);
			try {if (request!=null) request.free();}  finally {request=null;}
			try {if (response!=null) response.free();}  finally {response=null;}
		}
		catch(SQLException e){
			throw new MbUserException(this, "processVb6()", "", "", e.toString(), null);
		}
	}
	
	private void writeMessageBodyAsString(SQLXML resp, MbElement root) throws MbException{
		try{
			root.createElementAsLastChildFromBitstream(Decoders.KazWinToUtf8(resp.getString()).getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
		}
		catch(Exception e){
			throw new MbUserException(this, "writeMessageBodyVb6()", "", "", e.toString(), null);
		}
	}
	
	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) 
		{
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}
	}
	
	

}
