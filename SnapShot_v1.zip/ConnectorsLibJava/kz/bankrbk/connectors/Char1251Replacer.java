package kz.bankrbk.connectors;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.RecursiveAction;

public final class Char1251Replacer extends RecursiveAction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final byte[] Win1251 = { (byte)0xbc, (byte)0xb3, (byte)0xbe, (byte)0xba, (byte)0xbf, (byte)0xa2, (byte)0x9d, (byte)0xb4, (byte)0x9e, (byte)0xa3, (byte)0xb2, (byte)0xbd, (byte)0xaa, (byte)0xaf, (byte)0xa1, (byte)0x8d, (byte)0xa5, (byte)0x8e };
	private static final char[] SrcChars = createSrcChars();
	private static final char[] DstChars = "әіңғүұқөһӘІҢҒҮҰҚӨҺ".toCharArray();
	private static final int DST_CHARS_LEN = DstChars.length;
	private static final int THRESHOLD = 1000;
	
	private static char[] createSrcChars(){
		try {
			return new String(Win1251,"cp1251").toCharArray();
		} catch (UnsupportedEncodingException e) {
			// Можно дальше не работать
			throw new Error(e);
		}
	}
	
	private final char[] value;
	private final int from;
	private final int to;
	
	Char1251Replacer(char[] value, int from, int to){
		this.value = value;
		this.from = from;
		this.to = to;
	}

	@Override
	protected void compute() {
		// TODO Auto-generated method stub
		if (to - from < THRESHOLD){
			for (int i = from; i < to; i++) {
	        	for(int j=0; j < DST_CHARS_LEN; j++){
	        		if(value[i]==DstChars[j]){
	        			value[i]=SrcChars[j];
	        		}
	        	}
	        }
		}
		else {
			int mid = (from + to)/2;
			Char1251Replacer left = new Char1251Replacer(value, from, mid);
			Char1251Replacer right = new Char1251Replacer(value, mid, to);
			invokeAll(left, right);
			
		}
	}

}
