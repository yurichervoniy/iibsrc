package kz.bankrbk.emails;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;


public class SendMail_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new empty message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);
			MbElement msg = inMessage.getRootElement().getLastChild();
			// ----------------------------------------------------------
			// Add user code below
			String panReplaced = replaceCreditCardNumber(new String(msg.toBitstream(MbBLOB.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8"));
			MbElement omroot = outMessage.getRootElement();	
			omroot.createElementAsLastChildFromBitstream(panReplaced.getBytes("UTF-8"), MbBLOB.PARSER_NAME, "", "", "", 546, 1208, 0);
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}
	
	private static String  replaceCreditCardNumber(String text){
        final String MASKCARD = "$1****$3"; 
		//final String MASKCARD = "**card**";
        //final Pattern PATTERNCARD = Pattern.compile("\\b(4[0-9]{3})[0-9]{8,9}([0-9]{4})\\b");  
        final Pattern PATTERNCARD = Pattern.compile("\\b(4\\d{3})([ -]*?)(?:\\d[ -]*?){8}(\\d{4})\\b"); 
        //final Pattern PATTERNCARD = Pattern.compile("\\b(?:\\d[ -]*?){13,16}\\b"); 
        Matcher matcher = PATTERNCARD.matcher(text);
        if (matcher.find()) {
            return   matcher.replaceAll(MASKCARD);
        }
        return text;
   }

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
