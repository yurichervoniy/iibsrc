package kz.bankrbk.cbr.bik;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class LoadCbrBiks_JavaCompute extends MbJavaComputeNode {
	
	private static final String SERVICE = "CBRBIK";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new empty message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		try {
			Properties p = BrokerFacade.getUserDefinedConfigurableServiceProperties(SERVICE); 		    
			copyMessageHeaders(inMessage, outMessage);
			MbElement msg = inMessage.getRootElement().getLastChild();
			MbElement TimeoutRequest = msg.getFirstElementByPath("BIK/TimeoutRequest");
			Objects.requireNonNull(TimeoutRequest, "MbElement TimeoutRequest is null. Path evaluate BIK/TimeoutRequest");
			MbElement StartDate = TimeoutRequest.getFirstElementByPath("StartDate");
			Objects.requireNonNull(StartDate, "MbElement StartDate is null.");
			String startDateStr = StartDate.getValueAsString();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat siteFormat = new SimpleDateFormat("ddMMyyyy");
		    java.util.Date dt = sdf.parse(startDateStr);
		    MbElement periodElement = TimeoutRequest.getFirstElementByPath("Interval");
		    Objects.requireNonNull(periodElement, "MbElement periodElement is null.");
		    int interval = Integer.parseInt(periodElement.getValueAsString());
		    MbElement countElement = TimeoutRequest.getFirstElementByPath("Count");
		    Objects.requireNonNull(countElement, "MbElement Count is null.");
		    int count = Integer.parseInt(countElement.getValueAsString());
		    dt.setSeconds(dt.getSeconds()+(count-1)*interval); 
		    
		    String url = BrokerUtils.getProperty(p, "url");
		    Objects.requireNonNull(url, "URL is NULL");
		    url = url.replaceAll("#date#", siteFormat.format(dt));
		    String savePath = BrokerUtils.getProperty(p, "savePath");
		    Objects.requireNonNull(savePath, "savePath is NULL");
		    savePath = savePath.replaceAll("#date#", siteFormat.format(dt));
		    String filesDestination = BrokerUtils.getProperty(p, "filesDestination");
		    Objects.requireNonNull(filesDestination, "filesDestination is NULL");
		    String filesFilter = BrokerUtils.getProperty(p, "filesFilter").toLowerCase();
		    Objects.requireNonNull(filesFilter, "filesFilter is NULL");
		    List<String> filters = Arrays.asList(filesFilter.split(";"));
		    
		    if(!Files.exists(Paths.get(savePath).getParent()))
		    	throw new MbUserException(this, "evaluate()", "", "", String.format("savePath(%1$s).getParent not exists using check Files.exists(Path p)", savePath),null);
		    
		    if(!Files.exists(Paths.get(filesDestination)))
		    	throw new MbUserException(this, "evaluate()", "", "", String.format("filesDestination(%1$s) not exists using check Files.exists(Path p)", filesDestination),null);
		    
		    
		    URL website = new URL(url);
		    try(
		    	ReadableByteChannel rbc = Channels.newChannel(website.openStream());
		    	FileOutputStream fos = new FileOutputStream(savePath)
		    	){
		    	fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
		    	fos.close();
		    	rbc.close();
		    }
		    
		    try(ZipFile zf = new ZipFile(savePath)){
		    	 //FileSystem fileSystem = FileSystems.getDefault();
		    	 Enumeration<? extends ZipEntry> entries = zf.entries();
		         //Files.createDirectory(fileSystem.getPath(filesDestination));
		         while (entries.hasMoreElements())  {
		                ZipEntry entry = entries.nextElement();
		                
		                if (!entry.isDirectory()) 
		                {
		                	String fileName = entry.getName();
		                	if (filesFilter.isEmpty() || filters.contains(fileName.toLowerCase())){
		                		Path unzipF = Paths.get(filesDestination,entry.getName());
			                	try(BufferedInputStream bis = new BufferedInputStream(zf.getInputStream(entry));
			                		BufferedOutputStream fileOutput = new BufferedOutputStream(new FileOutputStream(unzipF.toString())) 
			                		){
			                			while(bis.available() > 0){
			                				fileOutput.write(bis.read());
			                			}
			                	}
		                	}
		                } 
		        }
		    }
		    
		    MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
			MbElement root= outParser.createElementAsFirstChild(MbXMLNSC.FIELD,"root",null);
			root.createElementAsLastChild(MbXMLNSC.FIELD,"filepath",savePath);	
			
		    
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
