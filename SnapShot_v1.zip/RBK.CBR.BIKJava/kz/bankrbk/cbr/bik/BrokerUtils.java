package kz.bankrbk.cbr.bik;

import java.util.Properties;

import com.ibm.broker.plugin.MbUserException;

public final class BrokerUtils {

private static final String PROPERTY_NOT_DEFINED = "No such property: "; 
	
	private BrokerUtils(){}
	
	public static String getProperty(final Properties props, final String key) throws MbUserException{
		String retval = props.getProperty(key); 
		if (retval == null) { 
            throw new MbUserException("BrokerUtils", "getProperty()", "", "", PROPERTY_NOT_DEFINED + key,  null); 
         } 
		return retval;
	}

}
