package kz.bankrbk.aml;

import java.util.Properties;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public final class GetRisks_JavaCompute extends MbJavaComputeNode {
	
	private static final String SERVICE = "AMLSERVICE";

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbMessage outLocalEnv = new MbMessage(assembly.getLocalEnvironment());

		try {
			Properties p = BrokerAmlFacade.getUserDefinedConfigurableServiceProperties(SERVICE); 
			String url = getProperty(p, "url");
			int timeOut = Integer.parseInt(getProperty(p, "timeout"));
			MbElement dest = outLocalEnv.getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
			MbElement http = dest.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RequestURL", url); 
			http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Timeout ", timeOut);
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		
		MbMessageAssembly outAssembly = new MbMessageAssembly(
				assembly,
				outLocalEnv,
				assembly.getExceptionList(),
				assembly.getMessage());
		
		out.propagate(outAssembly); 

	}
	
	public static String getProperty(final Properties props, final String key) throws MbUserException{
		String retval = props.getProperty(key); 
		if (retval == null) { 
            throw new MbUserException("BrokerUtils", "getProperty()", "", "", "NAPROP" + key,  null); 
         } 
		return retval;
	}

}
