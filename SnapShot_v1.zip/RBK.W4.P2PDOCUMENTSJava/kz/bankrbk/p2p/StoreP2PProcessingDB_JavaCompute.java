package kz.bankrbk.p2p;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLXML;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public final class StoreP2PProcessingDB_JavaCompute extends MbJavaComputeNode {
	
	private static final String JDBC_SERVICE = "IIB_DB";
	private static final String PROCEDURE_P2P = "{CALL dbo.spStoreP2PProcessing(?)}";
	private final static int PROCEDURE_TIMEOUT = 40;

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		//MbMessageAssembly outAssembly = null;
		try {
			MbElement msg = inMessage.getRootElement().getLastChild(); // Body of Message
			if (msg==null) 
				throw new MbUserException(this, "CreateP2PDocument-evaluate()", "", "", "Message MbElement is null", null);	
			String request = replaceCreditCardNumber(new String(msg.toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8"));
			Connection con = this.getJDBCType4Connection(JDBC_SERVICE, JDBC_TransactionType.MB_TRANSACTION_AUTO); // Do not close connection, Broker handles them//	
			if (con == null)
				throw new MbUserException(this, "getBrokerConnection("+JDBC_SERVICE+")", "", "", "BrokerConnection is null", null);
			try(CallableStatement st = con.prepareCall(PROCEDURE_P2P)) {	
				if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
					throw new MbUserException("prepareCall", "executeProcedureP2P("+PROCEDURE_P2P+")", "", "", "CallableStatement is null after call connection.prepareCall", null);
				st.setQueryTimeout(PROCEDURE_TIMEOUT);	
				SQLXML inMsg = con.createSQLXML();
				inMsg.setString(request);
				st.setSQLXML(1, inMsg);
				st.executeUpdate();
				inMsg.free();
				st.close();
			}
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(inAssembly);

	}
	
	private static String  replaceCreditCardNumber(String text){
        final String MASKCARD = "$1***$2"; 
        final Pattern PATTERNCARD = Pattern.compile("(4[0-9]{5})[0-9]{5,6}([0-9]{4})");  
        //final Pattern PATTERNCARD = Pattern.compile("\\b(4[0-9]{15})\\b");
        Matcher matcher = PATTERNCARD.matcher(text);
        if (matcher.find()) {
            return   matcher.replaceAll(MASKCARD);
        }
        return text;
   }

}
