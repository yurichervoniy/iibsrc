package kz.bankrbk.p2p;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Types;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;


public class CreateP2PDocument_JavaCompute extends MbJavaComputeNode {
	
	protected class DocumentP2P {
		protected String ID;
		protected String MessageId;
		protected String SourceRetNumber;
		protected String SoaMsg;
		
		public DocumentP2P(String id, String msgid, String srn, String msg){
			this.ID = id;
			this.MessageId = msgid;
			this.SourceRetNumber = srn;
			this.SoaMsg = msg;
		}
	}
	
	private static final String JDBC_SERVICE = "IIB_DB";
	private static final String PROCEDURE_P2P = "{CALL dbo.spCreateP2PDocument(?,?,?,?,?,?,?)}";
	private final static int PROCEDURE_TIMEOUT = 30;
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new empty message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);
		MbElement enviroment = inAssembly.getGlobalEnvironment().getRootElement();
		MbElement envVariables = enviroment.getFirstElementByPath("Variables");
		MbElement envUserProps = envVariables.getFirstElementByPath("userProperties");

		try {
			String rqID = envUserProps.getFirstElementByPath("RqUID").getValueAsString();
			String rqSystem = envUserProps.getFirstElementByPath("System").getValueAsString();
			
			copyMessageHeaders(inMessage, outMessage);
			MbElement msg = inMessage.getRootElement().getLastChild();
			if (msg==null) 
				throw new MbUserException(this, "CreateP2PDocument-evaluate()", "", "", "Message MbElement is null", null);			
			String request = new String(msg.toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8");
			MbElement omroot = outMessage.getRootElement();	
			Connection con = this.getJDBCType4Connection(JDBC_SERVICE, JDBC_TransactionType.MB_TRANSACTION_AUTO); // Do not close connection, Broker handles them//	
			if (con == null)
				throw new MbUserException(this, "getBrokerConnection("+JDBC_SERVICE+")", "", "", "BrokerConnection is null", null);
			
			DocumentP2P doc = executeProcedureP2P(con, rqID, rqSystem, request);
			omroot.createElementAsLastChildFromBitstream(doc.SoaMsg.getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
			MbElement docElement = envVariables.getFirstElementByPath("DOCUMENT");
			if (docElement==null)
				docElement = envVariables.createElementAsFirstChild(MbElement.TYPE_NAME, "DOCUMENT", null);
			docElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ID", doc.ID);
			docElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "MSGID", doc.MessageId);
			docElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SRN", doc.SourceRetNumber);
			
			
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(), null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);
	}
	
	public DocumentP2P executeProcedureP2P(final Connection conn, final String req, final String system, final String input) throws MbException, SQLException{
		if (conn == null) 
			throw new MbUserException("executeProcedureP2P", "executeProcedureP2P("+PROCEDURE_P2P+")", "", "", "Connection Parameter is null", null);
		try(CallableStatement st = conn.prepareCall(PROCEDURE_P2P)) {	
			if (st == null) // ������ ������������ NULL, ����� ������ ��������, �� ������
				throw new MbUserException("prepareCall", "executeProcedureP2P("+PROCEDURE_P2P+")", "", "", "CallableStatement is null after call connection.prepareCall", null);
			st.setQueryTimeout(PROCEDURE_TIMEOUT);	
			SQLXML request = conn.createSQLXML();
			request.setString(input);
			st.setString(1, req);
			st.setString(2, system);
			st.setSQLXML(3, request);
			st.registerOutParameter(4,Types.VARCHAR);
			st.registerOutParameter(5,Types.VARCHAR);
			st.registerOutParameter(6,Types.VARCHAR);
			st.registerOutParameter(7,Types.SQLXML);
			st.execute();
			String docId = st.getString(4);
			String msgId = st.getString(5);
			String srn = st.getString(6);
			SQLXML response = st.getSQLXML(7);
			if (response == null) 
				throw new MbUserException("executeProcedureP2P", "executeInteropProcedure("+PROCEDURE_P2P+")", "", "", "Response is null", null);
			String resp = response.getString();
			st.close();		
			if (resp == null) 
				throw new MbUserException("executeProcedureP2P", "executeInteropProcedure("+PROCEDURE_P2P+")", "", "", "Response getString() is null", null);
			return new DocumentP2P(docId,msgId,srn,resp);
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
